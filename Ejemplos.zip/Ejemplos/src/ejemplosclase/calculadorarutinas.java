package ejemplosclase;
    import java.io.InputStreamReader;
    import java.io.PrintStream;
    import java.io.BufferedReader;
    import java.io.IOException;

public class calculadorarutinas {
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;
    public static void main (final String [] args) throws IOException {
        menu();

    }

    static int leerNumero() throws IOException {//ya
        //Lectura de un numero
        int num = 0;  //Variable local
        out.print ("Ingrese un número entero: ");
        num = Integer.parseInt(in.readLine());
        return num;
    }

    static int suma(int pnum1, int pnum2){//ya
        //Devuelve la suma de los dos números
        return pnum1 + pnum2;
    }

    static int resta (int pnum1, int pnum2){
        //Calcula la resta
        return pnum1 - pnum2;
    }

    static int multiplicacion (int pnum1, int   pnum2){
        //Retorna la multiplicación
        return pnum1 * pnum2;
    }

    static boolean sonIguales(int pnum1, int pnum2){
       /*  if (pnum1 == pnum2)
            return true;
        else 
            return false; */

        boolean eq = false;

        if (pnum1== pnum2)
            eq = true;

        return eq;

        /* 
        return pnum1==pnum2; //Si son iguales devuelve true, si son distintas devuelve false
        */



    }

    static void desplegar(String pMsg, float pNum ){//ya
        //Despliega los resultados numéricos
        out.println(pMsg + " "+ pNum);
    }

    static void desplegarSiSonIguales(boolean presult){
        if (presult)
            out.println("Los dos números son iguales");
        else
            out.println("Los dos números son distintos");
    }

    static void desplegarSonIguales(int pnum1, int pnum2){

        if (sonIguales(pnum1, pnum2))
            out.println("Los dos números son iguales");
        else
            out.println("Los dos números son distintos");
    }

    static void menu()throws IOException{
        //Menú de las opciones del programa

        int num1 = 0;
        int num2 = 0;
        float result =0;


        int opc = 0; //Cero es la opción de salida del menú
        do{
            //Desplegar las opciones del menu
            out.println("[1] Leer valores ");
            out.println("[2] Calcular la suma ");
            out.println("[3] Calcular la resta ");
            out.println("[4] Calcular la multiplicacion ");
            out.println("[5] Determinar si son iguales ");
            out.println("[0] Salir del menu");
            
            //Lectura de la opcion
            out.print ("Digite su opcion->");
            opc = Integer.parseInt(in.readLine());

            //Ejecución de la acción
           
            switch (opc){
                case 1: num1 = leerNumero();
                        num2 = leerNumero();
                    break;
                case 2: result = suma(num1, num2);
                    desplegar("El resultado de la suma es ", result);
                    break;
                case 5: desplegarSonIguales(num1,num2);
                    break;
                case 0: out.println("ADIOS.....");
                    break;
                default:
                    out.println ("Opcion no válida");

            }
    }while (opc != 0);
 }
    
}
