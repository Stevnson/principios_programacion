package Semana11;

import java.io.InputStreamReader;
    import java.io.PrintStream;
    import java.io.BufferedReader;
    import java.io.IOException;
    
public class arrayVentas {
    
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    public static void main(String[] args)throws IOException {
        
        double[] ventas; 
        double promedio = 0; 
        double sumaVentas = 0;
        int mesesVentas = 0;

        //para reservar memoria ocupada por el array
        ventas = new double [12];

        //en este ciclo se lee el arreglo

        for (int i = 0; i < ventas.length; i++) {

            out.println("Por favor digite el monto vendido en el mes "+(i+1)+":");
            ventas[i]=Double.parseDouble(in.readLine());
            out.println(" ");
        }

        //en este ciclo se calcula la suma total de las ventas

        for (int i = 0; i < ventas.length; i++) {
            sumaVentas += ventas[i];
        }

        //teniendo la suma ya puedo calcular el promedio

        promedio = sumaVentas / 12;

        //para ver cuales meses se vendio mas que el promedio
        for (int i = 0; i < ventas.length; i++) {
            
            if (ventas[i]>promedio) {
                mesesVentas= mesesVentas + 1;
            }
        }

        //imprimiendo resultados

        //las ventas de cada mes

        for (int i = 0; i < ventas.length; i++) {
            out.println("Las ventas del mes "+(i+1)+" fueron de: " + ventas[i] + " colones.");
        }

        out.println("El promedio de las ventas fue de: "+promedio+ " colones.");

        out.println("La cantidad de meses en los que se vendio mas que el promedio fue de: "+mesesVentas +".");


    }
}
