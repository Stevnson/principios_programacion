/* 
package Semana11;
    import java.io.InputStreamReader;
    import java.io.PrintStream;
    import java.io.BufferedReader;
    import java.io.IOException;


public class metodos {
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;
​
    public static void main (final String [] args) throws IOException {
​
        int n = 0;
​
        out.print("Por favor digite el número de campos del vector: ");
        n = Integer.parseInt(in.readLine());
​
        int v[] = new int[n]; //Defino la variable v (vector) y solicito la memoria de los campos del vector
​
        leerValores(v);
        desplegarValores(v);
        desplegarMsg("Suma=", suma(v));
        desplegarMsg("Promedio =", promedio(v));
    }
​
    static void inicializar(int v[]){
        for(int i=0; i<v.length; i++){
            v[i]= 0;
        }
​
    }
​
    static void leerValores(int v[])throws IOException{
        for(int i=0; i<v.length; i++){
            out.print("Ingrese valor en la posicion ["+i+"]->");
            v[i]= Integer.parseInt(in.readLine());
        }
    }
​
    static int suma(int v[]){
        int total = 0;
        for(int i=0; i<v.length; i++){
            total+= v[i];
        }
        return total;
    }
​
    static float promedio(int v[]){
        return (float) suma(v)/v.length;
    } 
​
    static int mayor(int v[]){
        int m = 0;
        return m;
    }
​
    static int menor(int v[]){
        int m= 0;
        return m;
​
    }
​
    static void aumentar(int v[], int k){
        //Cada celda del vector lo aumenta en k
​
    }
​
    static boolean existe(int v[], int x){
        //Devolver true si el valor x se encuentra en el vector
        boolean encontrado = false;
        return encontrado;
    }
​
    static int posDato(int v[], int x){
        //Devolver la posición en el vector del valor de x, si no existe devuelve -1
        int indice = -1;
        return indice;
​
    }
​
    static int contar(int v[], int x){
        //Devuelve la cantidad de veces que el valor x se encuentra en v
        int cont = 0;
        return cont;
    }
​
    static boolean palindromo(int v[]){
        //Determinar si el vector un palindromo, estructura que es igual de izquierda a derecha que de derecha a izquierda
        boolean pali = false;
        return pali;
    }
​
​
    static void desplegarValores(int v[]){
        out.println("Valores del vector");
        out.println("==================");
        for(int i=0; i<v.length; i++){
            out.println("posicion["+i+"]="+v[i]);
        }
    }
​
    static void desplegarInverso(int v[]){
        //Desplegar los valores del vector del último al primero
    }
​
​
    static void desplegarMsg(String pmsg, float pnum){
        out.println (pmsg+" "+pnum);
    }
​
​
}

*/