package Semana11;

import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.IOException;

public class palindromo {
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;


    public static void main(String[] args) throws IOException{
        
        int n = 0;

        out.print("Por favor digite el numero de campos del vector: ");
        n = Integer.parseInt(in.readLine());

        int v[] = new int[n]; //Defino la variable v (vector) y solicito la memoria de los campos del vector

        leerValores(v);
        desplegarValores(v);
        esPalindromo(v);
        imprimirPalindromo(esPalindromo(v));

    }

//==========================================

    //lee valores

    static void leerValores(int v[])throws IOException{
        for(int i=0; i<v.length; i++){
            out.print("Ingrese valor en la posicion ["+i+"]->");
            v[i]= Integer.parseInt(in.readLine());
        }
    }
//========================================

    //evalua las celdas para definir si es palindromo
    static boolean esPalindromo(int v[]){

        boolean palindromo = true;

        //para comparar celdas
       for (int i = 0; i < v.length; i++) {
        
              if (v[i]!= v[(v.length-1)-i]) {
                palindromo=false;
                }
        }   

        return palindromo;

    }
    
//=============================================

//imprimir palindromo

static void imprimirPalindromo(boolean pPalindromo)throws IOException{

    if (pPalindromo) 
        out.println("Es palindromo");
    else
        out.println("No es palindromo");
    
}

//desplegar valores

static void desplegarValores(int v[]){
    out.println("Valores del vector");
    out.println("==================");
    for(int i=0; i<v.length; i++){
        out.println("posicion["+i+"]="+v[i]);
    }
}

}