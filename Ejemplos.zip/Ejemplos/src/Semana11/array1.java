package Semana11;
    import java.io.InputStreamReader;
    import java.io.PrintStream;
    import java.io.BufferedReader;
    import java.io.IOException;

public class array1 {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    public static void main(String[] args) throws IOException{
         // Arreglo para almacenar las temperaturas de la semana 
        double[] temperaturas; 
        double sumaTotal = 0, promedio = 0; int numDias;
 
        out.print("Por favor digite el número de días: "); 
        numDias = Integer.parseInt(in.readLine()); //Reserva en memoria de espacios para el arreglo 
        temperaturas = new double [numDias];

            for (int i = 0; i < temperaturas.length; i++) {
                out.print("Digite la temperatura del día " + (i + 1) + ": ");
                temperaturas[i] = Double.parseDouble(in.readLine()); 
                sumaTotal += temperaturas[i]; 
                } 
                promedio = sumaTotal / temperaturas.length;
                out.print("La temperatura promedio de esta semana fue de: " + promedio+ "\n");
                }
   
}

